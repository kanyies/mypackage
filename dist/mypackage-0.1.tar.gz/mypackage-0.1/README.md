# Mypackage
This file is an example of how I can build my own Python package.
This spans from being able to create folders and files to running actaul Python code.

## building this package locally
'python setup.py sdist
